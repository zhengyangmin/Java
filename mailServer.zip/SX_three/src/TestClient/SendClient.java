package TestClient;
import javax.swing.*;

import mailClient.MailService;
import mailClient.MailServiceService;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class SendClient {
    public static void myUI() {

        JFrame frame = new JFrame("�ʼ�����");
        frame.setBounds(400, 300, 400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponent(panel);
        frame.setVisible(true);
    }
    public static void placeComponent(JPanel panel) {
        panel.setLayout(null);
        /* ������������������λ�á�
         * setBounds(x, y, width, height)
         * x �� y ָ�����Ͻǵ����λ�ã��� width �� height ָ������Ĵ�С��
         */
        JLabel jLabel = new JLabel("�ռ�������");
        jLabel.setBounds(10, 20, 80, 25);
        panel.add(jLabel);

        JTextField addrContent = new JTextField(20);
        addrContent.setBounds(100, 20, 165, 25);
        panel.add(addrContent);

        JLabel jLabel2 = new JLabel("����");
        jLabel2.setBounds(10, 50, 80, 25);
        panel.add(jLabel2);

        JTextField title = new JTextField(20);
        title.setBounds(100, 50, 165, 25);
        panel.add(title);

        JLabel jLabel3 = new JLabel("�ʼ�����");
        jLabel3.setBounds(10, 100, 80, 25);
        panel.add(jLabel3);

        JTextArea mailContent = new JTextArea("����������", 7, 30);
        mailContent.setBounds(100, 100, 200, 50);
        panel.add(mailContent);

        JButton send = new JButton("����");
        send.setBounds(100, 200, 80, 25);
        panel.add(send);
        send.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String address=addrContent.getText();
                String subject= title.getText();//Subject
                String context =mailContent.getText();//Context
                String []des=address.split(",");
                MailService mailService1=new MailServiceService().getMailServicePort();
                List<String>list=new ArrayList<String>();
                boolean flag=true;
                for(String u:des)
                {
                  list.add(u);
                }
                boolean cur=mailService1.sendEmailBatch(list,context);
                String reString=" ";
                if(cur==true)
                {
                	reString="���ͳɹ�!";
                }
                else{
                	reString="����ʧ��";
                }
                JOptionPane.showMessageDialog(null, reString, "tips", JOptionPane.ERROR_MESSAGE);   
        }
        });
    }

    public static void main(String[] args) {
        myUI();
    }
}
