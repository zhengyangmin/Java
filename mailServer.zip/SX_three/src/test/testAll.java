package test;
import java.util.*;
public class testAll {
	public static void main(String []args)
	{
	
	}
}
