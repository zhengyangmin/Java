package test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.client.ClientConfig;
/**
 * Servlet implementation class HandEmail
 */

public class HandEmail extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public HandEmail() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String des = request.getParameter("des");
		String context = request.getParameter("context");
		int flag = 0;
		for(int i=0;i<des.length();i++)
		{
			if(des.charAt(i)==',')
			{
				flag=1;
				break;
			}
		}
		ClientConfig config = new ClientConfig();
        Client client = ClientBuilder.newClient(config);
        WebTarget target = client.target("http://localhost:8080/TestRest");
        String res=" ";
        if(flag==1)//��������
        {
        	 res=(String) target.path("rest").path("SendService").path("BatchSend").queryParam("url", des).queryParam("payload", context).request().accept(MediaType.TEXT_PLAIN).get(String.class);	
        }
        else{
         res=(String) target.path("rest").path("SendService").path("sendEmail").queryParam("url", des).queryParam("payload", context).request().accept(MediaType.TEXT_PLAIN).get(String.class);   
        }
        request.setAttribute("res", res);
        request.getRequestDispatcher("/Result.jsp").forward(request, response);
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
/*
 * wsimport -s D:\DataBase\AWSTestEclipse\WebServiceProject\src -p
 * http://localhost:9097/Service/mailService
 * 
 */
