package Client;


import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.client.ClientConfig;


import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class sendClient {
    public static void myUI() {

        JFrame frame = new JFrame("�����ʼ�����");
        frame.setBounds(650, 300, 400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponent(panel);
        frame.setVisible(true);
    }
    public static void placeComponent(JPanel panel) {
        panel.setLayout(null);
        /* ������������������λ�á�
         * setBounds(x, y, width, height)
         * x �� y ָ�����Ͻǵ����λ�ã��� width �� height ָ������Ĵ�С��
         */
        JLabel jLabel = new JLabel("�ռ�������");
        jLabel.setBounds(10, 20, 80, 25);
        panel.add(jLabel);

        JTextField addrContent = new JTextField("2811859162@qq.com",20);
        addrContent.setBounds(100, 20, 165, 25);
        panel.add(addrContent);

        JLabel jLabel2 = new JLabel("����");
        jLabel2.setBounds(10, 50, 80, 25);
        panel.add(jLabel2);

        JTextField title = new JTextField("����������",20);
        title.setBounds(100, 50, 165, 25);
        panel.add(title);

        JLabel jLabel3 = new JLabel("�ʼ�����");
        jLabel3.setBounds(10, 100, 80, 25);
        panel.add(jLabel3);

        JTextArea mailContent = new JTextArea("����������", 7, 30);
        mailContent.setBounds(100, 100, 200, 50);
        panel.add(mailContent);

        JButton send = new JButton("����");
        send.setBounds(100, 200, 80, 25);
        panel.add(send);
        send.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String address=addrContent.getText();
                String subject= title.getText();//Subject
                String context =mailContent.getText();//Context
        		int flag = 0;
        		for(int i=0;i<address.length();i++)
        		{
        			if(address.charAt(i)==',')
        			{
        				flag=1;
        				break;
        			}
        		}
        		ClientConfig config = new ClientConfig();
                Client client = ClientBuilder.newClient(config);
                WebTarget target = client.target("http://localhost:8080/TestRest");
                String res=" ";
                if(flag==1)//��������
                {
                   res=(String) target.path("rest").path("SendService").path("BatchSend").queryParam("url", address).queryParam("payload", context).request().accept(MediaType.TEXT_PLAIN).get(String.class);	
                }
                else{
                 res=(String) target.path("rest").path("SendService").path("sendEmail").queryParam("url", address).queryParam("payload", context).request().accept(MediaType.TEXT_PLAIN).get(String.class);   
                }
                System.out.print(res+"cur");
            
                String reString=" ";
                if(res.equals("true"))
                {
                	reString="���ͳɹ�!";
                }
                else{
                	reString="���ͳɹ�!";
                }
                JOptionPane.showMessageDialog(null, reString, "tips", JOptionPane.ERROR_MESSAGE);   
        }
        });
    }
    public static void main(String[] args) {
        myUI();
    }
}
// http://localhost:8080/TestRest/rest/SendService/sendEmail?url=1356931781@qq.com&payload=test

