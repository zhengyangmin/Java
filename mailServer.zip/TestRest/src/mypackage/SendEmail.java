package mypackage;

import javax.ws.rs.Path;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
@Path("/SendService")
public class SendEmail {
    @GET
    @Path("/sendEmail")
    @Produces(MediaType.TEXT_PLAIN)	
	public boolean sendEmail(@QueryParam("url")String url,@QueryParam("payload") String payload) {
		try 
		{
			MailUtils.sendMail(url, "test", payload);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
    @GET
    @Path("/BatchSend")
    @Produces(MediaType.TEXT_PLAIN)
    public boolean BatchSend(@QueryParam("url")String url,@QueryParam("payload")String payload)
    {
    	try {
			
    		String []des=url.split(",");
    		for(String s:des)
    		{
    			MailUtils.sendMail(s, "test",payload);
    		}
    		return true;
		} catch (Exception e) {
			// TODO: handle exception
		}
    	return false;
    }
    @GET
    @Path("/isvaild")
    @Produces(MediaType.TEXT_PLAIN)	
	public  boolean vaildateEmail(@QueryParam("email")String email) {
		// 123456@qq.com
		 if (email == null)
	            return false;
	        String rule = "[\\w!#$%&'*+/=?^_`{|}~-]+(?:\\.[\\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\\w](?:[\\w-]*[\\w])?\\.)+[\\w](?:[\\w-]*[\\w])?";
	        Pattern pattern;
	        Matcher matcher;
	        pattern = Pattern.compile(rule);
	        matcher = pattern.matcher(email);
	        if (matcher.matches())
	            return true;
	        else
	            return false;
	}
}
